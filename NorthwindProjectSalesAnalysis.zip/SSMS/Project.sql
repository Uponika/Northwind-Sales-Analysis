CREATE DATABASE Northwind_DW
GO

USE Northwind_DW
GO

CREATE TABLE dbo.DimDate (
    DateKey       INT NOT NULL,
    DateValue     DATE NOT NULL,
    CYear         SMALLINT NOT NULL,
    CMonth        TINYINT NOT NULL,
    DayNo         TINYINT NOT NULL,
    MonthName     VARCHAR(9) NOT NULL,
    DayOfWeekName VARCHAR(9) NOT NULL,    

    CONSTRAINT PK_DimDate PRIMARY KEY ( DateKey )
);
GO

CREATE OR ALTER PROCEDURE InsertDateDimension
AS
BEGIN
	SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @RowCt INT = 0;
	BEGIN TRANSACTION;
    DECLARE @startDate DATE = '1996-01-01'
    DECLARE @endDate DATE = '1998-12-31'

    WHILE @startDate <= @endDate
    BEGIN
        INSERT INTO dbo.DimDate(DateKey, DateValue, CYear, CMonth, DayNo, MonthName, DayOfWeekName)
        VALUES( CONVERT(INT, REPLACE(CONVERT(VARCHAR(10), @startDate, 112), '-', '')),
           @startDate,
           YEAR(@startDate),
           MONTH(@startDate),
           DAY(@startDate),
           DATENAME(mm,@startDate),
           DATENAME(dw,@startDate))
		SET @RowCt += @@ROWCOUNT;
		SET @startDate = DATEADD(DAY, 1,@startDate)
    END
	  IF @RowCt = 0
        BEGIN
            THROW 50001, 'No records found. Check with source system.', 1;
        END
    COMMIT TRANSACTION;
END
GO

EXECUTE InsertDateDimension;

SELECT * FROM [dbo].[DimDate];
GO

DROP TABLE IF EXISTS  dbo.DimCustomers

CREATE TABLE dbo.DimCustomers --SCD 2
(
��� CustomerKey INT Identity PRIMARY KEY,
	CustomerID VARCHAR(50) NULL,
��� CompanyName VARCHAR(50) NOT NULL,
��� ContactName VARCHAR(50) NULL,
	ContactTitle VARCHAR(50) NULL,
	CAddress VARCHAR(50) NULL,
    City VARCHAR(50) NULL,
	PostalCode VARCHAR(50) NULL,
	Country VARCHAR(50) NULL,
	Phone VARCHAR(50) NULL,
	startdate DATE NULL,
	Enddate DATE NULL
);
GO

CREATE SEQUENCE dbo.CustomerKey START WITH 1;
GO 

SELECT * FROM [dbo].[Customer_stg]
GO 
SELECT * FROM dbo.DimCustomers;
GO 

DROP TABLE [dbo].[Customer_stg];
GO

TRUNCATE dbo.DimProducts;
GO

CREATE TABLE dbo.DimProducts --SCD 2
(	ProductKey INT Identity PRIMARY KEY,
��� ProductID SMALLINT NOT NULL,
��� ProductName VARCHAR(50) NULL,
��� QuantityPerUnit VARCHAR(50) NULL,
	UnitPrice REAL NULL,
	UnitsinStock SMALLINT NULL,
	UnitsOnOrder SMALLINT NULL,
	startdate DATE  NULL,
	Enddate DATE  NULL
);

SELECT * FROM [dbo].[Product_stg];
GO 
SELECT * FROM [dbo].[DimProducts];
GO 
DROP TABLE [dbo].[DimProducts];
GO

TRUNCATE dbo.DimCategories;
GO

CREATE TABLE dbo.DimCategories( --SCD 1
	Categorykey INT Identity PRIMARY KEY,
	CategoryID INT NOT NULL,
	CategoryName VARCHAR(50) NOT NULL,
	CDescription VARCHAR(100) NULL
);

SELECT * FROM [dbo].[Categories_stg];
GO 

SELECT * FROM [dbo].[Categories_stg];
GO 

SELECT * FROM [dbo].[DimCategories];
GO
DROP TABLE dbo.DimOrders;
GO
TRUNCATE dbo.DimOrders;
GO

CREATE TABLE dbo.DimOrders --SCD 2
(	OrderKey INT Identity PRIMARY KEY,
��� OrderID INT NOT NULL,
	OrderDate Datetime NULL,
	ShippedDate Datetime NULL,
	ShipName VARCHAR(50) NULL,
	ShipAddress VARCHAR(50) NULL,
	ShipCity VARCHAR(50) NULL,
	ShipPostalCode VARCHAR(50) NULL,
	ShipCountry VARCHAR(50) NULL,
	startdate DATE NULL,
	Enddate DATE NULL
);
SELECT * FROM [dbo].[Orders_stg];
GO 
SELECT * FROM [dbo].[DimOrders];
GO 

CREATE TABLE dbo.DimEmployee --SCD 2
(
	EmployeeKey INT Identity PRIMARY KEY,
	EmployeeID INT NOT NULL,
	FirstName VARCHAR(20) NOT NULL,
	LastName VARCHAR(20) NOT NULL,
	HireDate DATETIME NULL,
	EAddress VARCHAR(50) NULL,
	City VARCHAR(15) NULL,
	PostalCode VARCHAR(10) NULL,
	Country VARCHAR(15) NULL,
	startdate DATE NULL,
	Enddate DATE NULL
);
GO

SELECT * FROM [dbo].[DimEmployee];
GO 

DROP TABLE [dbo].[DimEmployee];
GO

DROP TABLE dbo.FactSales;
GO

TRUNCATE dbo.FactSales;
GO


CREATE TABLE dbo.FactSales
(	DateKey INT NOT NULL,
	CustomerKey INT NOT NULL,
	ProductKey INT NOT NULL,
	UnitPrice Money NOT NULL,
	Quantity smallint NOT NULL,
	Discount Real  NOT NULL,
	TotalAmt Money NOT NULL

	CONSTRAINT FK_FactSales_DimDate_DateKey FOREIGN KEY(DateKey) REFERENCES dbo.DimDate(DateKey),
    CONSTRAINT FK_FactSales_DimCustomers_Customerkey FOREIGN KEY(CustomerKey) REFERENCES dbo.DimCustomers(CustomerKey),
	CONSTRAINT FK_FactSales_DimProducts_Productkey FOREIGN KEY(ProductKey) REFERENCES dbo.DimProducts(ProductKey),

);
GO
select * from [dbo].FactSales;

DROP TABLE dbo.FactShipped;
GO
TRUNCATE TABLE dbo.FactShipped;
GO

CREATE TABLE dbo.FactShipped
(	DateKey INT NOT NULL,
	CustomerKey INT NOT NULL,
	EmployeeKey INT NOT NULL,
	ShippedDate DATETIME NULL,
	CompanyName VARCHAR(50) NULL,
	RequiredDate DATETIME NULL,
	OrderDate DATETIME NULL,
	ShipmentReachedInTime VARCHAR(50),

	CONSTRAINT FK_FactShipped_DimDate_DateKey FOREIGN KEY(DateKey) REFERENCES dbo.DimDate(DateKey),
    CONSTRAINT FK_FactShipped_DimCustomers_Customerkey FOREIGN KEY(CustomerKey) REFERENCES dbo.DimCustomers(CustomerKey),
	CONSTRAINT FK_FactShipped_DimEmployee_Productkey FOREIGN KEY(EmployeeKey) REFERENCES dbo.DimEmployee(EmployeeKey),

);
GO
select * from [dbo].FactShipped;

--Dimension Tables
SELECT * FROM [dbo].[DimCategories];
SELECT * FROM [dbo].[DimCustomers];
SELECT * FROM [dbo].[DimDate];
SELECT * FROM [dbo].[DimOrders];
SELECT * FROM [dbo].[DimProducts];
SELECT * FROM [dbo].[Product_stg];

Go

CREATE TABLE dbo.FactSales1
(	DateKey INT NOT NULL,
	CustomerKey INT NOT NULL,
	ProductKey INT NOT NULL,
	OrderKey INT NOT NULL,
	ShippedDate DATETIME NULL,
	UnitPrice Money NOT NULL,
	Quantity smallint NOT NULL,
	Discount Real  NOT NULL,

	TotalAmt Money NOT NULL

	CONSTRAINT FK_FactSales1_DimDate_DateKey FOREIGN KEY(DateKey) REFERENCES dbo.DimDate(DateKey),
    CONSTRAINT FK_FactSales1_DimCustomers_Customerkey FOREIGN KEY(CustomerKey) REFERENCES dbo.DimCustomers(CustomerKey),
	CONSTRAINT FK_FactSales1_DimProducts_Productkey FOREIGN KEY(ProductKey) REFERENCES dbo.DimProducts(ProductKey),
	CONSTRAINT FK_FactSales1_DimOrders_Orderkey FOREIGN KEY(OrderKey) REFERENCES dbo.DimOrders(OrderKey),
);
GO